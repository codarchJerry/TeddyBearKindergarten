package com.codarch.teddybearkindergarten

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.codarch.teddybearkindergarten.ui.login.RegisterActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun register(view: View){
        var intent = Intent(applicationContext,
            RegisterActivity::class.java)
        startActivity(intent)

    }

    fun parent_contol(view: View){
        var intent = Intent(applicationContext,
            ParentControl::class.java)
        startActivity(intent)
    }

    fun kindergarten_control(view: View){
        var intent = Intent(applicationContext,
            KindergartenControl::class.java)
        startActivity(intent)
    }
}