package com.codarch.teddybearkindergarten.data.model

data class StudentModel(val studentName: String, val parentName: String, val phoneNumber: String, val homeAddress: String, val userPassword: String)